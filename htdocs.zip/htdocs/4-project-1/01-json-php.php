<?php 
	$arr = ['金','川','习'];
	echo json_encode($arr);
 ?>