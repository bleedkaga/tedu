<?php 
	$score = [12,32,143,56,33,67];

	for($i = 0; $i < count($score); $i++){
		if($i)
		echo $score[$i]."/";
	}
 ?>