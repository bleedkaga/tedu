<?php 
	$name = $_REQUEST['name'];

	echo "欢迎 $name 光临";
 ?>