<?php 
	@$name = $_REQUEST['name'];

	echo 'The first ajax Applications';
?>