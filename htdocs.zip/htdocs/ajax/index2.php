<?php 
	echo '我的Ajax练习';
 ?>